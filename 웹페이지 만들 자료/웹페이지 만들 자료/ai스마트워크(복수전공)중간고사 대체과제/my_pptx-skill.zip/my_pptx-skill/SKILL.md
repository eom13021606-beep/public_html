---
name: my_pptx-skill
description: 엄서현(한림대학교 식품영양학과)의 대학생활용 PowerPoint 제작 스킬. 업로드한 네이비·골드 배경 템플릿으로 '표지(발표제목·발표자) → 목차 → 개조식 내용 슬라이드 → Q&A(질문 유도)' 구조의 .pptx 를 만든다. 도형·다이어그램은 PPT 네이티브 도형, 아이콘은 편집 가능한 SVG 그래픽으로 넣고 편집 가능 여부를 자동 검증한다. 사용자가 PPT, 파워포인트, 발표 자료, 수업 발표, 조별 과제 발표, 팀 프로젝트 발표, 학회·세미나·공모전 발표, 슬라이드, 발표 준비를 언급하면 형식을 따로 말하지 않아도 반드시 이 스킬을 사용할 것.
---

# my_pptx-skill — 엄서현의 대학생활 PPT 스킬

## 고정 규칙 (사용자와 확정한 내용)
| 항목 | 확정 내용 |
|---|---|
| 용도 | 수업 발표 / 팀 프로젝트 / 학회·세미나·공모전 — 범용 |
| 배경 | `assets/template.pptx` (네이비·골드, 16:9). 원본은 `assets/original_background.pptx` |
| 구성 | ① 표지: 발표제목 + **한림대학교 식품영양학과 / 엄서현** ② 목차 ③ 내용 슬라이드(개조식) ④ 마지막: **Q&A + "궁금한 점을 자유롭게 질문해 주세요"** |
| 글꼴 | **맑은 고딕** (제목·본문 전체) |
| 푸터 | **슬라이드 번호만** (날짜·푸터 문구 없음, 표지 제외) |
| 그림 | **핵심 슬라이드에만** 넣는다 (프로세스·비교·카드·타임라인·핵심수치) |
| 도형 | 전부 **PPT 네이티브 도형** → PowerPoint 에서 바로 수정 가능 |
| 아이콘 | **편집 가능한 SVG** 를 pptx 안에 삽입 (PNG 대체이미지 + svgBlip) |
| 발표자 정보 변경 | `assets/config.json` 수정 |

## 작업 순서 (반드시 이 순서)

### 0단계. 인터뷰 — grill-me 방식으로 하나씩 묻고 확정
빠진 정보가 있으면 **한 번에 하나씩** 묻는다. 매 질문에 **추천 답을 함께 제시**하고, 답이 오면 다음 질문으로 간다. 사용자가 이미 말했거나 추론 가능한 것은 묻지 않는다. ask_user_input 도구가 있으면 선택지 버튼으로 묻는다.
1. **발표 주제·제목** 과 **한 문장 핵심 메시지**는? 
2. **발표 유형·청중**(교수님 / 조원 / 심사위원)과 **발표 시간(분)**? → 슬라이드 수 = 시간 ÷ 1.5~2분 (표지·목차·Q&A 제외)
3. **꼭 넣어야 할 내용·자료·수치·출처**가 있는가? (없으면 사용자가 준 자료만 사용, 근거 없는 수치는 만들지 않는다)
4. **그림을 넣을 핵심 슬라이드**는 어디인가? (추천: 과정 설명 → process, 두 대상 비교 → compare, 3~4개 개념 → cards, 일정·역사 → timeline, 수치 강조 → stats)
5. 섹션 구분 슬라이드가 필요한가? (슬라이드 10장 이상이면 추천 → 목차가 섹션 기준이 됨)
6. 발표자 정보가 달라지는가? (기본: 한림대학교 식품영양학과 엄서현 / 팀 발표면 팀원 추가 여부)

### 1단계. 구조 설계 → `deck.json` 작성
- 스키마와 예시: `references/deck_schema.md`, `assets/examples/sample_deck.json`
- 문장은 **개조식**: `references/writing_guide.md` 를 읽고 따른다.
- 표지·목차·Q&A 는 스크립트가 자동 생성 → `slides` 에는 내용 슬라이드만 쓴다.
- 아이콘 이름은 `references/icon_catalog.md` 에서 고른다 (식품영양·학업 40종).

### 2단계. 빌드
```bash
pip install -r requirements.txt            # 최초 1회: python-pptx, lxml, cairosvg, fonttools, pillow
python scripts/build_deck.py deck.json 발표자료.pptx            # 기본: 아이콘 = 편집 가능 SVG 그래픽
python scripts/build_deck.py deck.json 발표자료.pptx --icon-mode native   # 아이콘도 순수 PPT 도형으로
```
- 출력: `발표자료.pptx` + `발표자료_svg/` (삽입된 SVG 원본, Illustrator·Inkscape·PowerPoint 에서 편집 가능)
- `[넘침 위험]` 경고가 나오면 **글을 줄이거나 슬라이드를 나눈 뒤 다시 빌드**한다.

### 3단계. 편집 가능 검증 (필수 — 통과 전에는 전달 금지)
```bash
python scripts/verify_editable.py 발표자료.pptx
```
확인 항목: 래스터 그림 0개 / SVG 벡터 유효성 / SVG→네이티브 도형 변환 가능 / 다이어그램 네이티브 도형·글자 도형 개수 / 글자·색·크기·위치 수정 후 저장·재열기 반영 / 빈 플레이스홀더 없음.
**실패(❌)가 하나라도 있으면 원인을 고쳐 다시 빌드 → 재검증.** 방법은 `references/editability.md`.

### 4단계. 시각 QA
```bash
soffice --headless --convert-to pdf 발표자료.pptx && pdftoppm -jpeg -r 60 발표자료.pdf page
```
이미지로 확인: 글자 넘침·겹침·정렬·여백, 제목 위치 일관성, 아이콘 대비. (샌드박스는 맑은 고딕이 없어 대체 글꼴로 보이므로 글자 폭이 실제와 ±10% 다를 수 있다 — 칸에 여유를 둘 것)

### 5단계. 전달
`발표자료.pptx` 와 `발표자료_svg/` 를 전달하고, 한 줄 요약(슬라이드 수·그림 넣은 슬라이드·검증 결과)만 덧붙인다.

## 디자인 원칙 (요약 — 상세는 `references/design_guide.md`)
- 슬라이드당 메시지 1개, 개조식 3~5줄, 본문 ≥ 14pt, 제목 36pt, 제목 위치·크기 통일.
- 색은 테마 색만 사용(네이비 TEXT_1, 골드 ACCENT_1) → 디자인 탭에서 한 번에 바꿀 수 있다.
- 제목 아래 장식선·색 띠 금지. 글머리 슬라이드는 필요할 때만 옆 아이콘을 넣는다.
- 맨 위 템플릿 배경 이미지는 레이아웃에 있으므로 삭제·교체하지 않는다.

## 파일 구조
```
my_pptx-skill/
├─ SKILL.md
├─ requirements.txt
├─ assets/   template.pptx · original_background.pptx · config.json · icons/*.svg(40) · examples/sample_deck.json
├─ references/  deck_schema.md · writing_guide.md · design_guide.md · editability.md · icon_catalog.md · decisions.md
└─ scripts/  build_deck.py · native_shapes.py · svg_embed.py · verify_editable.py · prepare_template.py · make_icons.js
```
템플릿을 새 배경으로 바꾸려면: `assets/original_background.pptx` 교체 → `python scripts/prepare_template.py`.
