# 아이콘 카탈로그 (40종)

deck.json 의 `icon` 값에 이름을 쓴다. 출처: Material Design Icons (Apache-2.0).
새 아이콘 추가: `scripts/make_icons.js` 의 ICONS 표에 이름→Material 아이콘 컴포넌트명을 추가하고 `NODE_PATH=$(npm root -g) node scripts/make_icons.js` 실행. 직접 만든 SVG 는 `assets/icons/이름.svg` 로 넣되, 단색 path 만 쓰고 기본색을 `#163B5C` 로 지정(빌드 시 색이 자동 치환됨).

| 이름 | 용도 | 파일 |
|---|---|---|
| `leaf` | 잎·친환경(식물성 식품) | `assets/icons/leaf.svg` |
| `food` | 식사·식당 | `assets/icons/food.svg` |
| `meal` | 한 끼 식사 | `assets/icons/meal.svg` |
| `bakery` | 빵·탄수화물 | `assets/icons/bakery.svg` |
| `egg` | 달걀·단백질 | `assets/icons/egg.svg` |
| `water` | 물방울·수분·지방 | `assets/icons/water.svg` |
| `bowl` | 국·면 요리 | `assets/icons/bowl.svg` |
| `lunch` | 샌드위치·간편식 | `assets/icons/lunch.svg` |
| `kitchen` | 조리·급식 | `assets/icons/kitchen.svg` |
| `fitness` | 운동·근력 | `assets/icons/fitness.svg` |
| `scale` | 체중·BMI | `assets/icons/scale.svg` |
| `health` | 건강·안전 | `assets/icons/health.svg` |
| `heart` | 심장·건강 | `assets/icons/heart.svg` |
| `medicine` | 약·보충제 | `assets/icons/medicine.svg` |
| `cart` | 장보기·구매 | `assets/icons/cart.svg` |
| `book` | 책·이론 | `assets/icons/book.svg` |
| `school` | 학교·교육 | `assets/icons/school.svg` |
| `science` | 실험·과학 | `assets/icons/science.svg` |
| `chart` | 분석·인사이트 | `assets/icons/chart.svg` |
| `bar` | 막대 그래프 | `assets/icons/bar.svg` |
| `idea` | 아이디어·결론 | `assets/icons/idea.svg` |
| `people` | 사람들·팀 | `assets/icons/people.svg` |
| `target` | 목표 | `assets/icons/target.svg` |
| `check` | 확인·완료 | `assets/icons/check.svg` |
| `search` | 검색·조사 | `assets/icons/search.svg` |
| `list` | 체크리스트 | `assets/icons/list.svg` |
| `clock` | 시간·규칙성 | `assets/icons/clock.svg` |
| `edit` | 작성·메모 | `assets/icons/edit.svg` |
| `question` | 질문 | `assets/icons/question.svg` |
| `chat` | 토론·소통 | `assets/icons/chat.svg` |
| `flag` | 목표 지점 | `assets/icons/flag.svg` |
| `star` | 핵심·중요 | `assets/icons/star.svg` |
| `warning` | 주의·위험 | `assets/icons/warning.svg` |
| `compare` | 비교 | `assets/icons/compare.svg` |
| `cycle` | 순환·반복 | `assets/icons/cycle.svg` |
| `globe` | 세계·글로벌 | `assets/icons/globe.svg` |
| `trend` | 증가 추세 | `assets/icons/trend.svg` |
| `doc` | 문서·보고서 | `assets/icons/doc.svg` |
| `calendar` | 일정 | `assets/icons/calendar.svg` |
| `computer` | 노트북·IT | `assets/icons/computer.svg` |
