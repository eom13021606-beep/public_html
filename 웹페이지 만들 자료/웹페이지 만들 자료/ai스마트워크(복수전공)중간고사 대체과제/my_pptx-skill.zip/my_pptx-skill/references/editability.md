# 편집 가능성 — 구조와 검증

## 어떻게 편집 가능하게 만드는가
| 요소 | 방식 | PowerPoint 에서 할 수 있는 것 |
|---|---|---|
| 카드·원·화살표·선·VS 등 모든 도형 | 기본 도형(prstGeom) + 텍스트 상자, 그룹으로 묶음 | 글자·색·크기·위치 수정, 그룹 해제(Ctrl+Shift+G) 후 개별 편집, 도형 서식 |
| 색 | 테마 색 참조(TEXT_1, ACCENT_1 …) | 디자인 > 변형 > 색 으로 전체 일괄 변경 |
| 아이콘(기본 `svg` 모드) | SVG 그래픽(PNG 대체 이미지 + `asvg:svgBlip`) | 그래픽 형식 > 채우기로 색 변경, **우클릭 > 도형으로 변환**으로 점 편집 |
| 아이콘(`--icon-mode native`) | SVG path → DrawingML 자유형(custGeom) 직접 변환 | 변환 없이 바로 점 편집·채우기·윤곽선 |
| SVG 원본 파일 | `*_svg/` 폴더로 별도 저장 | Illustrator / Inkscape 등에서 편집 후 재삽입 |

## 검증 (`scripts/verify_editable.py`)
1. 슬라이드 위 `p:pic` 은 전부 svgBlip 이어야 함 (일반 이미지 = 편집 불가 → 실패)
2. 내장 SVG 가 올바른 XML 이며 `path/circle/rect/g…` 만 사용 (image·foreignObject·script·data:image 금지)
3. 모든 path 를 custGeom 으로 변환 가능 (= 순수 도형으로 바꿀 수 있음)
4. 다이어그램 그룹이 네이티브 도형 ≥ 4개 + 글자 있는 도형 ≥ 2개
5. 수정 시뮬레이션: 글자·글자색·크기·채우기·위치를 실제로 바꿔 저장 → 재열기 후 반영 확인
6. 빈 플레이스홀더("텍스트를 입력하려면 클릭") 없음

## 수동 확인 팁 (실제 PowerPoint)
- SVG 아이콘 클릭 → 상단 "그래픽 형식" 탭이 보이면 정상. 우클릭 → "도형으로 변환" 가능.
- 다이어그램 클릭 → 그룹 전체 선택, 텍스트 더블클릭 → 바로 수정.
- 변환 충실도: `--icon-mode native` 로 빌드해 렌더링하면 SVG 모드와 동일하게 보임을 확인함(체크 구멍·내부 곡선 포함).

## 한계
- 자동 검증은 python-pptx/XML 수준이며, 'PowerPoint 앱 안에서 도형으로 변환' 동작은 앱에서 직접 확인해야 한다(구버전 PowerPoint 2016 이하는 SVG 미지원 → `--icon-mode native` 사용).
- Google 슬라이드는 SVG 그래픽을 PNG 대체 이미지로 보여줄 수 있다 → 구글 슬라이드 제출 시 `--icon-mode native` 권장.
