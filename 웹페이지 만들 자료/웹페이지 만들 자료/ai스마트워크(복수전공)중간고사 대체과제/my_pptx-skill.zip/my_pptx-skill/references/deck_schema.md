# deck.json 스키마

```json
{
  "title": "발표 제목 (2줄 이내, 20자 안팎)",
  "presenter": "선택: 표지 발표자 문구를 직접 지정 (기본은 assets/config.json)",
  "closing_message": "선택: 마지막 슬라이드 문구 변경 (기본: 궁금한 점을 자유롭게 질문해 주세요)",
  "slides": [ ... 내용 슬라이드 ... ]
}
```
표지·목차·Q&A 는 자동 생성. 목차는 `section` 슬라이드가 있으면 섹션 제목, 없으면 내용 슬라이드 제목(최대 8개).
모든 슬라이드에 `"notes": "발표 대본"` (선택)을 넣으면 발표자 노트가 들어간다.

| type | 용도 | 필드 | 글자 수 가이드 |
|---|---|---|---|
| `bullets` | 기본 개조식 | `bullets`: 문자열 또는 `{"text","sub":[…]}`, 선택 `icon` | 줄당 ≤ 30자, 3~5줄 |
| `process` | 순서·단계(2~5) | `steps`: `{heading, text, icon?, label?}` | 제목 ≤ 8자, 설명 ≤ 20자 |
| `compare` | A vs B | `left`/`right`: `{heading, icon?, points[3~4]}` | 항목 ≤ 18자 |
| `cards` | 핵심 개념(2~4) | `cards`: `{heading, text, icon?}` | 제목 ≤ 8자, 설명 ≤ 25자 |
| `timeline` | 일정·흐름(3~6) | `events`: `{label, text}` | 설명 ≤ 20자 |
| `stats` | 핵심 수치(2~4) | `stats`: `{value, label, text?, icon?}` | 값 ≤ 8자 |
| `section` | 섹션 구분 | `title`, `subtitle?` | – |

- 칸 크기 대비 글이 길면 빌드 시 `[넘침 위험]` 경고가 출력된다.
- 도형 이름은 한글로 붙어 있다(예: `단계1_제목`) → 선택 창(Alt+F10)에서 찾기 쉽다.
