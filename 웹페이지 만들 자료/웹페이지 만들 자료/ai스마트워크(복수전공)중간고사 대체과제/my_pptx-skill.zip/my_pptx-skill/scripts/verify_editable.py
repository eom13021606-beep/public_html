#!/usr/bin/env python3
"""pptx 편집 가능 여부 자동 검증 (필수 단계).

검사 항목
 [1] 슬라이드 위 그림(p:pic)은 전부 '편집 가능한 SVG(svgBlip)'여야 함 — 일반 래스터 그림이 있으면 실패
 [2] 내장 SVG 파일: 올바른 XML, 허용 벡터 요소만 사용(image/foreignObject/script 금지), path 존재
 [3] SVG -> PPT 네이티브 도형 변환 테스트: 모든 path 를 DrawingML 자유형(custGeom)으로 변환 가능한지
 [4] 다이어그램: 슬라이드의 도형이 네이티브 도형(prstGeom/custGeom)+텍스트 상자로 구성되고 개수가 충분한지
 [5] 수정 시뮬레이션: python-pptx 로 글자·색·크기·위치를 실제로 바꿔 저장 → 다시 열어 반영 확인
 [6] 빈 플레이스홀더("텍스트를 입력하려면 클릭") 잔존 여부
사용: python scripts/verify_editable.py out.pptx    (실패 시 종료코드 1)
"""
import sys, io, json, pathlib, tempfile, zipfile, subprocess, shutil, argparse, re
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from lxml import etree
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE
import svg_embed

NS = {"a": svg_embed.NS_A, "p": svg_embed.NS_P, "r": svg_embed.NS_R, "asvg": svg_embed.NS_ASVG}
OK, NG = "✅", "❌"


def X(el, expr):
    return etree._Element.xpath(el, expr, namespaces=NS)


def walk(shapes):
    for s in shapes:
        yield s
        if s.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from walk(s.shapes)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("pptx")
    a = ap.parse_args()
    fails, report = [], []
    def check(ok, msg):
        report.append((OK if ok else NG) + " " + msg)
        if not ok: fails.append(msg)

    prs = Presentation(a.pptx)
    n_pic = n_svg = n_native = n_text = 0
    svg_blobs = {}
    for si, slide in enumerate(prs.slides, 1):
        for sh in walk(slide.shapes):
            el = sh._element
            tag = etree.QName(el).localname
            if tag == "pic":
                n_pic += 1
                sv = X(el, ".//asvg:svgBlip")
                if not sv:
                    check(False, "슬라이드 %d: 편집 불가한 래스터 그림 '%s' (SVG 아님)" % (si, sh.name)); continue
                rid = sv[0].get("{%s}embed" % NS["r"])
                part = slide.part.related_part(rid)
                if part.content_type != "image/svg+xml":
                    check(False, "슬라이드 %d: svgBlip 대상이 SVG 가 아님 (%s)" % (si, part.content_type)); continue
                n_svg += 1; svg_blobs[(si, sh.name, n_svg)] = part.blob
            elif tag == "sp":
                if X(el, "./p:spPr/a:prstGeom|./p:spPr/a:custGeom"):
                    n_native += 1
                if sh.has_text_frame and sh.text_frame.text.strip():
                    n_text += 1
    check(True, "슬라이드 %d장 | 네이티브 도형 %d개 | 텍스트 요소 %d개 | SVG 그래픽 %d개 | 래스터 그림 %d개" % (len(prs.slides), n_native, n_text, n_svg, n_pic - n_svg))

    # [2][3] SVG 검사 + 네이티브 변환 가능성
    for (si, name, k), blob in svg_blobs.items():
        try:
            root = etree.fromstring(blob)
        except Exception as e:
            check(False, "슬라이드 %d '%s': SVG XML 오류 %s" % (si, name, e)); continue
        tags = {etree.QName(e).localname for e in root.iter() if isinstance(e.tag, str)}
        bad = tags - svg_embed.ALLOWED_TAGS
        if bad or b"data:image" in blob:
            check(False, "슬라이드 %d '%s': 편집 불가 요소 포함 %s" % (si, name, sorted(bad))); continue
        try:
            vw, vh, ds = svg_embed.svg_paths(blob.decode("utf8"))
            geom, ncmd = svg_embed.paths_to_custgeom_xml(vw, vh, ds)
            etree.fromstring(geom.encode("utf8"))
            ok = len(ds) > 0 and ncmd >= 3
        except Exception as e:
            ok, ncmd = False, str(e)
        check(ok, "슬라이드 %d '%s': SVG 벡터 OK → 네이티브 도형 변환 가능 (path %d개, 명령 %s개)" % (si, name, len(ds) if ok else 0, ncmd))

    # [4] 다이어그램 그룹 점검
    for si, slide in enumerate(prs.slides, 1):
        for sh in slide.shapes:
            if sh.shape_type == MSO_SHAPE_TYPE.GROUP and sh.name.startswith("다이어그램_"):
                kids = list(walk(sh.shapes))
                nat = [k for k in kids if etree.QName(k._element).localname in ("sp", "cxnSp")]
                txt = [k for k in nat if k.has_text_frame and k.text_frame.text.strip()]
                if sh.name == "다이어그램_옆아이콘":
                    icons = [k for k in kids if etree.QName(k._element).localname in ("pic", "sp") and k.name.startswith(("슬라이드_아이콘", "아이콘"))]
                    check(len(nat) >= 1 and len(icons) >= 1, "슬라이드 %d '%s': 네이티브 원 도형 + 아이콘 (편집 가능)" % (si, sh.name))
                else:
                    check(len(nat) >= 4 and len(txt) >= 2, "슬라이드 %d '%s': 네이티브 도형 %d개 / 글자 있는 도형 %d개 (그룹 해제·개별 편집 가능)" % (si, sh.name, len(nat), len(txt)))

    # [5] 수정 시뮬레이션
    tmp = pathlib.Path(tempfile.mkdtemp()) / "edit_test.pptx"
    p2 = Presentation(a.pptx)
    edits = 0
    for si, slide in enumerate(p2.slides, 1):
        for sh in walk(slide.shapes):
            if etree.QName(sh._element).localname == "sp" and sh.has_text_frame and sh.text_frame.text.strip() and not sh.is_placeholder:
                r = sh.text_frame.paragraphs[0].runs[0]
                r.text = r.text + "·수정됨"; r.font.size = Pt(15); r.font.color.rgb = RGBColor(0xC9, 0x97, 0x36)
                if sh.shape_type != MSO_SHAPE_TYPE.TEXT_BOX:
                    sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor(0xE4, 0xC8, 0x75)
                sh.left = sh.left + Inches(0.05); sh.width = sh.width + Inches(0.05)
                edits += 1
                break
    p2.save(tmp)
    p3 = Presentation(tmp); seen = 0
    for slide in p3.slides:
        for sh in walk(slide.shapes):
            if sh.has_text_frame and "·수정됨" in sh.text_frame.text:
                seen += 1
    check(edits > 0 and seen == edits, "수정 시뮬레이션: 글자·글자색·크기·채우기·위치 변경 %d건 → 저장 후 재열기 반영 %d건" % (edits, seen))

    # [6] 빈 플레이스홀더
    empty = [(si, sh.name) for si, sl in enumerate(prs.slides, 1) for sh in sl.placeholders
             if sh.has_text_frame and not sh.text_frame.text.strip() and sh.placeholder_format.type is not None
             and "SLIDE_NUMBER" not in str(sh.placeholder_format.type)]
    check(not empty, "빈 플레이스홀더 없음" if not empty else "빈 플레이스홀더 %s" % empty)

    print("\n".join(report))
    print("\n결과:", "모든 검사 통과 ✅" if not fails else "실패 %d건 ❌" % len(fails))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
