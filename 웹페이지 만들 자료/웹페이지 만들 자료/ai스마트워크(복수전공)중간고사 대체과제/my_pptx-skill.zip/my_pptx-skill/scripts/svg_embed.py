#!/usr/bin/env python3
"""SVG 아이콘을 pptx 안에 '편집 가능한 SVG 그래픽'으로 삽입하는 모듈 (+ SVG -> PPT 네이티브 도형 변환).

두 가지 삽입 방식
 * add_svg_picture(...)   : PowerPoint '그래픽(SVG)'으로 삽입. PNG 대체 이미지 + svgBlip(원본 SVG) 구조.
                            PowerPoint에서 우클릭 > '도형으로 변환'(Convert to Shape) 하면 점 편집까지 가능,
                            '그래픽 형식 > 채우기'로 색 변경도 바로 가능.
 * add_svg_as_native(...) : SVG path 를 DrawingML 자유형 도형(custGeom)으로 직접 변환해 삽입.
                            변환 단계 없이 처음부터 '점 편집/채우기/윤곽선' 가능한 순수 PPT 도형.
"""
import io, re, copy, subprocess, shutil, tempfile, pathlib
from lxml import etree
from pptx.opc.package import Part
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml import parse_xml
from pptx.util import Emu

NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
NS_ASVG = "http://schemas.microsoft.com/office/drawing/2016/SVG/main"
SVG_EXT_URI = "{96DAC541-7B7A-43D3-8B79-37D633B846F1}"
BASE_COLOR = "#163B5C"          # assets/icons 의 기본색 (치환 대상)
ALLOWED_TAGS = {"svg", "g", "path", "circle", "rect", "ellipse", "line", "polyline", "polygon", "defs", "title", "desc"}


def load_svg(path, color_hex=None):
    """SVG 텍스트를 읽고 색을 치환. color_hex 예: 'C99736' (# 없이)"""
    txt = pathlib.Path(path).read_text(encoding="utf8")
    if color_hex:
        txt = txt.replace(BASE_COLOR, "#" + color_hex.lstrip("#").upper())
    return txt


def svg_to_png(svg_text, px=512):
    try:
        import cairosvg
        return cairosvg.svg2png(bytestring=svg_text.encode("utf8"), output_width=px, output_height=px)
    except ImportError:
        pass
    if shutil.which("rsvg-convert"):
        return subprocess.run(["rsvg-convert", "-w", str(px), "-h", str(px)], input=svg_text.encode("utf8"),
                              capture_output=True, check=True).stdout
    raise RuntimeError("SVG 래스터화 도구가 없습니다. `pip install cairosvg` 를 실행하세요.")


def _next_id(slide):
    ids = [int(i) for i in slide.shapes._spTree.xpath("//@id") if str(i).isdigit()]
    return max(ids + [1]) + 1


# ───────────────────────── 방식 1: 편집 가능한 SVG 그래픽 ─────────────────────────
def add_svg_picture(slide, container_shapes, svg_text, x, y, size, name="아이콘(SVG)", alt=""):
    """container_shapes: slide.shapes 또는 group.shapes. x,y,size 는 EMU."""
    png = svg_to_png(svg_text)
    pic = container_shapes.add_picture(io.BytesIO(png), x, y, size, size)
    pic.name = name
    pic._element.nvPicPr.cNvPr.set("descr", alt or name)
    pkg = slide.part.package
    partname = pkg.next_partname("/ppt/media/image%d.svg")
    svg_part = Part(partname, "image/svg+xml", pkg, svg_text.encode("utf8"))
    rid = slide.part.relate_to(svg_part, RT.IMAGE)
    blip = pic._element.xpath(".//a:blip")[0]
    ext_lst = parse_xml(
        '<a:extLst xmlns:a="%s"><a:ext uri="%s"><asvg:svgBlip xmlns:asvg="%s" xmlns:r="%s" r:embed="%s"/></a:ext></a:extLst>'
        % (NS_A, SVG_EXT_URI, NS_ASVG, NS_R, rid))
    blip.append(ext_lst)
    return pic


# ───────────────────────── 방식 2: SVG -> 네이티브 자유형 도형 ─────────────────────────
def svg_paths(svg_text):
    """(viewBox w, h, [path d ...]) — fill="none" path 는 제외"""
    root = etree.fromstring(svg_text.encode("utf8"))
    vb = (root.get("viewBox") or "0 0 24 24").replace(",", " ").split()
    vw, vh = float(vb[2]), float(vb[3])
    ds = []
    for el in root.iter("{http://www.w3.org/2000/svg}path"):
        if el.get("fill") == "none" or not el.get("d"):
            continue
        ds.append(el.get("d"))
    return vw, vh, ds


def paths_to_custgeom_xml(vw, vh, ds, scale=1000):
    from fontTools.svgLib.path import parse_path
    from fontTools.pens.recordingPen import RecordingPen
    W, H = int(vw * scale), int(vh * scale)
    pt = lambda p: '<a:pt x="%d" y="%d"/>' % (round(p[0] * scale), round(p[1] * scale))
    out, ncmd = [], 0
    for d in ds:
        pen = RecordingPen()
        parse_path(d, pen)
        for op, args in pen.value:
            if op == "moveTo":
                out.append("<a:moveTo>%s</a:moveTo>" % pt(args[0])); ncmd += 1
            elif op == "lineTo":
                out.append("<a:lnTo>%s</a:lnTo>" % pt(args[0])); ncmd += 1
            elif op == "curveTo":
                out.append("<a:cubicBezTo>%s</a:cubicBezTo>" % "".join(pt(a) for a in args[:3])); ncmd += 1
            elif op == "qCurveTo":
                out.append("<a:quadBezTo>%s</a:quadBezTo>" % "".join(pt(a) for a in args[:2])); ncmd += 1
            elif op in ("closePath", "endPath"):
                out.append("<a:close/>")
    xml = ('<a:custGeom xmlns:a="%s"><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/>'
           '<a:rect l="0" t="0" r="r" b="b"/><a:pathLst><a:path w="%d" h="%d">%s</a:path></a:pathLst></a:custGeom>'
           % (NS_A, W, H, "".join(out)))
    return xml, ncmd


def add_svg_as_native(slide, container, svg_text, x, y, size, color_hex="163B5C", name="아이콘(도형)"):
    """container: slide.shapes 또는 group.shapes. 네이티브 자유형 도형 1개로 삽입 (점 편집 가능)."""
    vw, vh, ds = svg_paths(svg_text)
    geom, ncmd = paths_to_custgeom_xml(vw, vh, ds)
    sid = _next_id(slide)
    sp = parse_xml(
        '<p:sp xmlns:p="%s" xmlns:a="%s"><p:nvSpPr><p:cNvPr id="%d" name="%s"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>%s'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr>'
        '<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="ko-KR"/></a:p></p:txBody></p:sp>'
        % (NS_P, NS_A, sid, name, x, y, size, size, geom, color_hex.lstrip("#").upper()))
    container._spTree.append(sp) if hasattr(container, "_spTree") else container._grpSp.append(sp)
    return sp


def add_icon(slide, container, icon_svg_path, x, y, size, color_hex, mode="svg", name="아이콘", alt=""):
    svg = load_svg(icon_svg_path, color_hex)
    if mode == "native":
        return add_svg_as_native(slide, container, svg, x, y, size, color_hex, name=name)
    return add_svg_picture(slide, container, svg, x, y, size, name=name, alt=alt or name)


if __name__ == "__main__":
    print(__doc__)
