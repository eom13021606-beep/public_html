#!/usr/bin/env python3
"""원본 배경 pptx(assets/original_background.pptx) -> 정리된 assets/template.pptx 생성.

하는 일
 1) 샘플 슬라이드 8장 전부 삭제 (배경 이미지는 '레이아웃'에 들어 있어 그대로 유지됨)
 2) 불필요한 레이아웃 삭제 (Color Palette & Font / Designed by PresentationGo)
 3) 테마·마스터·레이아웃의 글꼴을 '맑은 고딕'으로 통일
 4) 마스터에 남은 출처(광고) 도형 제거, 문서 속성(작성자) 설정
사용: python scripts/prepare_template.py
"""
import re, pathlib
from pptx import Presentation

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "assets" / "original_background.pptx"
DST = ROOT / "assets" / "template.pptx"
FONT = "Malgun Gothic"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"


def set_fonts(el):
    n = 0
    for tag in ("latin", "ea", "cs"):
        for f in el.iter("{%s}%s" % (A, tag)):
            tf = f.get("typeface", "")
            if tf and not tf.startswith("+") and tf not in ("Arial", "Symbol", "Wingdings"):
                f.set("typeface", FONT)
                for k in ("panose", "pitchFamily", "charset"):
                    f.attrib.pop(k, None)
                n += 1
    return n


def main():
    prs = Presentation(str(SRC))
    # 1) 슬라이드 삭제
    sldIdLst = prs.slides._sldIdLst
    for sldId in list(sldIdLst):
        prs.part.drop_rel(sldId.rId)
        sldIdLst.remove(sldId)
    # 2) 레이아웃 정리
    for lay in list(prs.slide_layouts):
        if lay.name.startswith("Color Palette") or lay.name.startswith("Designed by"):
            prs.slide_layouts.remove(lay)
    # 3) 글꼴 (테마)
    master = prs.slide_master
    for rel in master.part.rels.values():
        if rel.reltype.endswith("/theme"):
            tp = rel.target_part
            xml = tp.blob.decode("utf8")
            xml = re.sub(r'(<a:(?:major|minor)Font>\s*<a:latin typeface=")[^"]*(")', r'\g<1>%s\g<2>' % FONT, xml)
            xml = re.sub(r'(<a:(?:major|minor)Font>\s*<a:latin typeface="[^"]*"[^>]*/>\s*<a:ea typeface=")[^"]*(")', r'\g<1>%s\g<2>' % FONT, xml)
            xml = xml.replace("Aptos Display", FONT).replace('"Aptos"', '"%s"' % FONT)
            tp._blob = xml.encode("utf8")
    cnt = set_fonts(master._element)
    for lay in prs.slide_layouts:
        cnt += set_fonts(lay._element)
    # 4) 마스터의 출처/광고 도형 제거 (슬라이드 밖 y>7.5in 의 텍스트 도형)
    for sp in list(master.shapes):
        if sp.top is not None and sp.top > prs.slide_height and sp.has_text_frame:
            sp._element.getparent().remove(sp._element)
    cp = prs.core_properties
    cp.author = "엄서현"
    cp.title = "my_pptx-skill template"
    cp.comments = ""
    prs.save(str(DST))
    print("saved", DST, "| layouts:", [l.name for l in prs.slide_layouts], "| font replaced:", cnt)


if __name__ == "__main__":
    main()
