#!/usr/bin/env python3
"""슬라이드용 'PPT 네이티브 도형' 다이어그램 모음.

모든 요소는 PowerPoint 기본 도형(둥근 사각형, 원, 화살표, 직선, 텍스트 상자)이라
PowerPoint 안에서 글자·색·크기·위치를 바로 수정할 수 있다.
도형은 그룹으로 묶여 있고(이름: '다이어그램_프로세스' 등) 그룹을 풀어(Ctrl+Shift+G) 개별 편집도 가능.
색은 모두 테마 색(TEXT_1, ACCENT_1 …)을 참조 → 디자인 > 변형 에서 일괄 변경 가능.
"""
import math, pathlib
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.dml import MSO_THEME_COLOR as TC
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
from lxml import etree
import svg_embed

ICON_DIR = pathlib.Path(__file__).resolve().parent.parent / "assets" / "icons"
# 콘텐츠 영역(인치): 제목 아래 ~ 하단 물결 위
X0, Y0, W, H = 0.92, 2.0, 11.5, 3.65

NAVY, NAVY2, GOLD, GOLD_L, STEEL, ICE, DEEP, MIST, BG2 = (
    TC.TEXT_1, TC.TEXT_2, TC.ACCENT_1, TC.ACCENT_2, TC.ACCENT_3, TC.ACCENT_4, TC.ACCENT_5, TC.ACCENT_6, TC.BACKGROUND_2)
WHITE = "FFFFFF"
HEX = {"navy": "0A2545", "gold": "C99736", "white": "FFFFFF", "deep": "234B73"}

WARNINGS = []


def _c(fmt, c):
    if isinstance(c, str):
        fmt.rgb = RGBColor.from_string(c)
    else:
        fmt.theme_color = c


def est_lines(text, width_in, size_pt):
    """글자 폭 추정(한글=1em, 영문/숫자=0.55em)으로 줄 수 계산 — 넘침 사전 경고용"""
    em = size_pt / 72.0
    lines = 0
    for para in str(text).split("\n"):
        w = sum(em if ord(ch) > 0x2E80 else em * 0.55 for ch in para) * 1.08
        lines += max(1, math.ceil(w / max(width_in, 0.1)))
    return lines


def check_fit(label, text, width_in, height_in, size_pt, line_gap=1.3):
    need = est_lines(text, width_in, size_pt) * size_pt * line_gap / 72.0
    if need > height_in:
        WARNINGS.append("[넘침 위험] %s: '%s…' (필요 %.2fin > 칸 %.2fin) → 글을 줄이거나 슬라이드를 나누세요" % (label, str(text)[:14], need, height_in))


def _shape(shapes, kind, x, y, w, h, fill=None, line=None, name=None, radius=None, line_w=1.0):
    s = shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
    s.shadow.inherit = False
    if fill is None:
        s.fill.background()
    else:
        s.fill.solid(); _c(s.fill.fore_color, fill)
    if line is None:
        s.line.fill.background()
    else:
        s.line.fill.solid(); _c(s.line.color, line); s.line.width = Pt(line_w)
    if radius is not None and kind == MSO_SHAPE.ROUNDED_RECTANGLE:
        s.adjustments[0] = radius
    if name:
        s.name = name
    return s


def _text(shape, text, size, bold=False, color=NAVY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, margin=0.08, bullets=False):
    tf = shape.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(margin)
    tf.margin_top = tf.margin_bottom = Inches(0.04)
    lines = text if isinstance(text, list) else str(text).split("\n")
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if bullets:
            pPr = p._p.get_or_add_pPr()
            pPr.set("marL", "228600"); pPr.set("indent", "-228600")
            bu = etree.SubElement(pPr, qn("a:buChar")); bu.set("char", "•")
            p.space_after = Pt(6)
        r = p.add_run(); r.text = ln
        r.font.size = Pt(size); r.font.bold = bold
        _c(r.font.color, color)
    return shape


def _textbox(shapes, x, y, w, h, text, size, bold=False, color=NAVY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.TOP, name=None, bullets=False):
    tb = shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    _text(tb, text, size, bold, color, align, anchor, margin=0.05, bullets=bullets)
    if name:
        tb.name = name
    return tb


def _icon(slide, shapes, icon, x, y, size, color_key, mode, name):
    if not icon:
        return
    p = ICON_DIR / (icon + ".svg")
    if not p.exists():
        WARNINGS.append("[아이콘 없음] '%s' → assets/icons 의 이름을 확인하세요" % icon)
        return
    svg_embed.add_icon(slide, shapes, p, Inches(x), Inches(y), Inches(size), HEX[color_key], mode, name=name, alt="%s 아이콘" % icon)


def _card(shapes, x, y, w, h, name):
    return _shape(shapes, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, fill=WHITE, line=ICE, name=name, radius=0.06)


def _fit_h(texts, width, size, start, minh=2.9):
    """카드 안 글 길이에 맞춰 카드 높이를 정하고, 콘텐츠 영역 세로 가운데에 배치"""
    need = start + max([est_lines(t, width, size) * size * 1.3 / 72 for t in texts] + [0.3]) + 0.25
    ch = min(H - 0.1, max(minh, need))
    return ch, Y0 + 0.05 + (H - 0.1 - ch) / 2


def _finish(group):
    group.shapes._spTree.recalculate_extents()
    return group


# ─────────────────────────── 1) 프로세스 (순서/단계) ───────────────────────────
def process(slide, steps, mode="svg"):
    n = len(steps); assert 2 <= n <= 5, "process 는 2~5단계"
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_프로세스"; sh = g.shapes
    gap = 0.5 if n <= 4 else 0.42
    cw = (W - gap * (n - 1)) / n
    ch, y = _fit_h([st.get("text", "") for st in steps], cw - 0.34, 14, 1.98)
    for i, st in enumerate(steps):
        x = X0 + i * (cw + gap)
        _card(sh, x, y, cw, ch, "단계%d_카드" % (i + 1))
        d = 0.86
        _shape(sh, MSO_SHAPE.OVAL, x + (cw - d) / 2, y + 0.22, d, d, fill=NAVY, name="단계%d_원" % (i + 1))
        if st.get("icon"):
            _icon(slide, sh, st["icon"], x + (cw - 0.5) / 2, y + 0.4, 0.5, "white", mode, "단계%d_아이콘" % (i + 1))
        else:
            _textbox(sh, x + (cw - d) / 2, y + 0.22, d, d, str(i + 1), 24, True, WHITE, anchor=MSO_ANCHOR.MIDDLE, name="단계%d_번호" % (i + 1))
        _textbox(sh, x + 0.1, y + 1.18, cw - 0.2, 0.3, st.get("label", "STEP %d" % (i + 1)), 12, True, GOLD, name="단계%d_라벨" % (i + 1))
        _textbox(sh, x + 0.1, y + 1.45, cw - 0.2, 0.5, st["heading"], 18, True, NAVY, name="단계%d_제목" % (i + 1))
        check_fit("process 단계%d 제목" % (i + 1), st["heading"], cw - 0.3, 0.5, 18)
        _textbox(sh, x + 0.12, y + 1.98, cw - 0.24, ch - 2.05, st.get("text", ""), 14, False, NAVY, name="단계%d_설명" % (i + 1))
        check_fit("process 단계%d 설명" % (i + 1), st.get("text", ""), cw - 0.34, ch - 2.05, 14)
        if i < n - 1:
            _shape(sh, MSO_SHAPE.RIGHT_ARROW, x + cw + (gap - 0.34) / 2, y + ch / 2 - 0.17, 0.34, 0.34, fill=GOLD, name="화살표%d" % (i + 1))
    return _finish(g)


# ─────────────────────────── 2) 비교 (A vs B) ───────────────────────────
def compare(slide, left, right, mode="svg"):
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_비교"; sh = g.shapes
    gap = 1.0; cw = (W - gap) / 2; y = Y0 + 0.05; hh = 0.75; ch = H - 0.1
    for k, (side, x, fillc, txtc, ic) in enumerate([(left, X0, NAVY, WHITE, "white"), (right, X0 + cw + gap, GOLD, NAVY, "navy")]):
        tag = "좌" if k == 0 else "우"
        _card(sh, x, y, cw, ch, "%s_카드" % tag)
        _shape(sh, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, cw, hh, fill=fillc, name="%s_머리말" % tag, radius=0.25)
        off = 0.2
        if side.get("icon"):
            _icon(slide, sh, side["icon"], x + 0.22, y + 0.15, 0.45, ic, mode, "%s_아이콘" % tag); off = 0.8
        _textbox(sh, x + off, y + 0.08, cw - off - 0.2, hh - 0.16, side["heading"], 20, True, txtc,
                 align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.MIDDLE, name="%s_제목" % tag)
        pts = side["points"]
        _textbox(sh, x + 0.25, y + hh + 0.2, cw - 0.5, ch - hh - 0.3, pts, 16, False, NAVY, align=PP_ALIGN.LEFT, name="%s_내용" % tag, bullets=True)
        check_fit("compare %s 내용" % tag, "\n".join(pts), cw - 0.8, ch - hh - 0.3, 16, 1.55)
    d = 0.8
    v = _shape(sh, MSO_SHAPE.OVAL, X0 + cw + (gap - d) / 2, y + ch / 2 - d / 2, d, d, fill=GOLD_L, line=WHITE, name="VS_원", line_w=2.5)
    _text(v, "VS", 18, True, NAVY, margin=0.0)
    return _finish(g)


# ─────────────────────────── 3) 카드 (핵심 포인트 2~4) ───────────────────────────
def cards(slide, items, mode="svg"):
    n = len(items); assert 2 <= n <= 4, "cards 는 2~4개"
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_카드"; sh = g.shapes
    gap = 0.35; cw = (W - gap * (n - 1)) / n
    ch, y = _fit_h([it.get("text", "") for it in items], cw - 0.38, 14, 1.95)
    for i, it in enumerate(items):
        x = X0 + i * (cw + gap)
        _card(sh, x, y, cw, ch, "카드%d" % (i + 1))
        d = 1.0
        _shape(sh, MSO_SHAPE.OVAL, x + (cw - d) / 2, y + 0.25, d, d, fill=BG2, line=GOLD, name="카드%d_원" % (i + 1), line_w=2)
        if it.get("icon"):
            _icon(slide, sh, it["icon"], x + (cw - 0.58) / 2, y + 0.46, 0.58, "navy", mode, "카드%d_아이콘" % (i + 1))
        _textbox(sh, x + 0.1, y + 1.4, cw - 0.2, 0.5, it["heading"], 18, True, NAVY, name="카드%d_제목" % (i + 1))
        check_fit("cards 카드%d 제목" % (i + 1), it["heading"], cw - 0.3, 0.5, 18)
        _textbox(sh, x + 0.14, y + 1.95, cw - 0.28, ch - 2.05, it.get("text", ""), 14, False, NAVY, name="카드%d_설명" % (i + 1))
        check_fit("cards 카드%d 설명" % (i + 1), it.get("text", ""), cw - 0.38, ch - 2.05, 14)
    return _finish(g)


# ─────────────────────────── 4) 타임라인 ───────────────────────────
def timeline(slide, events, mode="svg"):
    n = len(events); assert 3 <= n <= 6, "timeline 은 3~6개"
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_타임라인"; sh = g.shapes
    seg = W / n; ly = Y0 + 1.15
    ln = sh.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(X0 + 0.2), Inches(ly), Inches(X0 + W - 0.2), Inches(ly))
    ln.line.width = Pt(3); ln.line.fill.solid(); _c(ln.line.color, STEEL); ln.name = "타임라인_선"
    for i, ev in enumerate(events):
        cx = X0 + seg * i + seg / 2
        _textbox(sh, cx - seg / 2 + 0.05, ly - 0.85, seg - 0.1, 0.5, ev["label"], 20, True, NAVY, name="시점%d_라벨" % (i + 1))
        d = 0.42
        _shape(sh, MSO_SHAPE.OVAL, cx - d / 2, ly - d / 2, d, d, fill=GOLD, line=WHITE, name="시점%d_점" % (i + 1), line_w=3)
        bx = cx - seg / 2 + 0.08
        _card(sh, bx, ly + 0.45, seg - 0.16, H - 1.75, "시점%d_카드" % (i + 1))
        _textbox(sh, bx + 0.05, ly + 0.5, seg - 0.26, H - 1.85, ev.get("text", ""), 14, False, NAVY, anchor=MSO_ANCHOR.MIDDLE, name="시점%d_설명" % (i + 1))
        check_fit("timeline 시점%d" % (i + 1), ev.get("text", ""), seg - 0.36, H - 1.85, 14)
    return _finish(g)


# ─────────────────────────── 5) 핵심 수치 ───────────────────────────
def stats(slide, items, mode="svg"):
    n = len(items); assert 2 <= n <= 4, "stats 는 2~4개"
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_핵심수치"; sh = g.shapes
    gap = 0.35; cw = (W - gap * (n - 1)) / n
    ch, y = _fit_h([it.get("text", "") for it in items], cw - 0.38, 14, 2.4, 3.1)
    for i, it in enumerate(items):
        x = X0 + i * (cw + gap)
        _card(sh, x, y, cw, ch, "수치%d_카드" % (i + 1))
        if it.get("icon"):
            _icon(slide, sh, it["icon"], x + (cw - 0.55) / 2, y + 0.25, 0.55, "gold", mode, "수치%d_아이콘" % (i + 1))
        _textbox(sh, x + 0.1, y + 0.9, cw - 0.2, 0.95, it["value"], 44, True, NAVY, anchor=MSO_ANCHOR.MIDDLE, name="수치%d_값" % (i + 1))
        check_fit("stats 수치%d 값" % (i + 1), it["value"], cw - 0.3, 0.95, 44)
        _textbox(sh, x + 0.1, y + 1.9, cw - 0.2, 0.45, it["label"], 18, True, NAVY, name="수치%d_이름" % (i + 1))
        _textbox(sh, x + 0.14, y + 2.4, cw - 0.28, ch - 2.45, it.get("text", ""), 14, False, NAVY, name="수치%d_설명" % (i + 1))
        check_fit("stats 수치%d 설명" % (i + 1), it.get("text", ""), cw - 0.38, ch - 2.45, 14)
    return _finish(g)


# ─────────────────────────── 6) 글머리 슬라이드 옆 아이콘 장식 ───────────────────────────
def side_icon(slide, icon, mode="svg"):
    g = slide.shapes.add_group_shape(); g.name = "다이어그램_옆아이콘"; sh = g.shapes
    d = 2.9; x = 9.2; y = 2.15
    _shape(sh, MSO_SHAPE.OVAL, x, y, d, d, fill=WHITE, line=GOLD, name="아이콘_바탕원", line_w=3)
    _icon(slide, sh, icon, x + (d - 1.6) / 2, y + (d - 1.6) / 2, 1.6, "navy", mode, "슬라이드_아이콘")
    return _finish(g)
