// 아이콘 SVG 생성기 (Material Design Icons, Apache-2.0 / react-icons 경유)
// 사용: NODE_PATH=$(npm root -g) node scripts/make_icons.js
// 결과: assets/icons/<이름>.svg  (단색 벡터 path, 색은 fill 속성 하나라서 PowerPoint에서 쉽게 편집/변환됨)
const React = require("react");
const { renderToStaticMarkup } = require("react-dom/server");
const md = require("react-icons/md");
const fs = require("fs"), path = require("path");

const ICONS = {
  // 식품영양 특화
  leaf: "MdEco", food: "MdRestaurant", meal: "MdSetMeal", bakery: "MdBakeryDining",
  egg: "MdEgg", water: "MdWaterDrop", bowl: "MdRamenDining", lunch: "MdLunchDining",
  kitchen: "MdSoupKitchen", fitness: "MdFitnessCenter", scale: "MdMonitorWeight",
  health: "MdHealthAndSafety", heart: "MdFavorite", medicine: "MdMedication", cart: "MdShoppingBasket",
  // 학업 범용
  book: "MdMenuBook", school: "MdSchool", science: "MdScience", chart: "MdInsights",
  bar: "MdBarChart", idea: "MdLightbulb", people: "MdGroups", target: "MdTrackChanges",
  check: "MdCheckCircle", search: "MdSearch", list: "MdChecklist", clock: "MdSchedule",
  edit: "MdEditNote", question: "MdHelp", chat: "MdForum", flag: "MdFlag", star: "MdStar",
  warning: "MdWarning", compare: "MdCompareArrows", cycle: "MdAutorenew", globe: "MdPublic",
  trend: "MdTrendingUp", doc: "MdDescription", calendar: "MdEvent", computer: "MdLaptop",
};
const out = path.join(__dirname, "..", "assets", "icons");
fs.mkdirSync(out, { recursive: true });
let n = 0, miss = [];
for (const [name, comp] of Object.entries(ICONS)) {
  if (!md[comp]) { miss.push(name + ":" + comp); continue; }
  let svg = renderToStaticMarkup(React.createElement(md[comp], { size: 256 }));
  // react-icons 는 stroke/fill 을 currentColor 로 두므로 명시 색으로 치환 + 표준 xmlns
  svg = svg.replace(/currentColor/g, "#163B5C");
  if (!/xmlns=/.test(svg)) svg = svg.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
  svg = svg.replace(/ style="[^"]*"/, "");
  fs.writeFileSync(path.join(out, name + ".svg"), svg);
  n++;
}
console.log("icons:", n, "missing:", miss.join(", ") || "none");
