#!/usr/bin/env python3
"""deck.json -> 엄서현 스타일 pptx 생성기.

구성(고정): 1) 표지(발표제목+학교·학과·이름)  2) 목차  3~N-1) 내용(개조식)  N) Q&A(질문 유도)
사용:
  python scripts/build_deck.py deck.json out.pptx [--icon-mode svg|native]
결과:
  out.pptx                : 완성본 (도형=PPT 네이티브, 아이콘=편집 가능한 SVG 그래픽)
  out_svg/*.svg           : 슬라이드에 삽입된 편집 가능 SVG 원본 파일(색 적용본)
"""
import sys, json, copy, argparse, pathlib, re
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import PP_PLACEHOLDER
from pptx.enum.dml import MSO_THEME_COLOR as TC
import native_shapes as ns
import svg_embed

ROOT = pathlib.Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "assets" / "template.pptx"
CONFIG = json.load(open(ROOT / "assets" / "config.json", encoding="utf8"))
L_TITLE, L_CONTENT, L_CONTENT_B, L_SEC_L, L_SEC_R, L_CLOSE = 0, 1, 2, 3, 4, 5


def ph(slide, idx):
    for p in slide.placeholders:
        if p.placeholder_format.idx == idx:
            return p


def drop_unused(slide, keep=()):
    for p in list(slide.placeholders):
        if p.placeholder_format.idx not in keep:
            p._element.getparent().remove(p._element)


def add_slide_number(slide):
    for p in slide.slide_layout.placeholders:
        if p.placeholder_format.type == PP_PLACEHOLDER.SLIDE_NUMBER:
            el = copy.deepcopy(p._element)
            ids = [int(i) for i in slide.shapes._spTree.xpath("//@id") if str(i).isdigit()]
            el.xpath(".//p:cNvPr")[0].set("id", str(max(ids + [1]) + 1))
            slide.shapes._spTree.append(el)
            return


def set_title(slide, text, size=None):
    t = slide.shapes.title
    t.text_frame.text = text
    if size:
        for r in t.text_frame.paragraphs[0].runs:
            r.font.size = Pt(size)
    ns.check_fit("제목", text, t.width / 914400 - 0.2, t.height / 914400, size or 36, 1.1)


def fill_bullets(body, items, has_icon):
    tf = body.text_frame
    if has_icon:
        body.left, body.top, body.width, body.height = Inches(0.92), Inches(2.0), Inches(8.0), Inches(3.7)
    else:
        body.left, body.top, body.width, body.height = Inches(0.92), Inches(2.0), Inches(11.0), Inches(3.7)
    first = True
    total_h = 0.0
    w_in = body.width / 914400 - 0.5
    for it in items:
        text, subs = (it, []) if isinstance(it, str) else (it["text"], it.get("sub", []))
        p = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
        r = p.add_run(); r.text = text; r.font.size = Pt(24); r.font.bold = True
        total_h += ns.est_lines(text, w_in, 24) * 24 * 1.3 / 72 + 0.14
        for s in subs:
            sp = tf.add_paragraph(); sp.level = 1
            rr = sp.add_run(); rr.text = s; rr.font.size = Pt(20)
            total_h += ns.est_lines(s, w_in - 0.4, 20) * 20 * 1.3 / 72 + 0.14
    if total_h > 3.7:
        ns.WARNINGS.append("[넘침 위험] 글머리 슬라이드 내용이 많습니다 (예상 %.1fin > 3.7in) → 항목 수를 줄이거나 나누세요" % total_h)


def build(spec, out, icon_mode="svg"):
    prs = Presentation(str(TEMPLATE))
    lay = prs.slide_layouts
    cfg = CONFIG
    presenter = " ".join(x for x in (cfg["school"], cfg["department"]) if x) + "\n" + cfg["name"]
    if spec.get("presenter"):
        presenter = spec["presenter"]
    slides = spec["slides"]

    # 1) 표지
    s = prs.slides.add_slide(lay[L_TITLE])
    s.shapes.title.text_frame.text = spec["title"]
    ns.check_fit("표지 제목", spec["title"], 6.6, 2.6, 44, 1.1)
    tfp = ph(s, 1).text_frame
    for i, line in enumerate(presenter.split("\n")):
        pp = tfp.paragraphs[0] if i == 0 else tfp.add_paragraph()
        rr = pp.add_run(); rr.text = line
        if i == 0: rr.font.size = Pt(22)
    drop_unused(s, keep=(0, 1))

    # 2) 목차
    sections = [x for x in slides if x["type"] == "section"]
    toc_src = sections if sections else [x for x in slides if x["type"] != "section"]
    toc = [x["title"] for x in toc_src][:8]
    s = prs.slides.add_slide(lay[L_CONTENT])
    set_title(s, "목차")
    body = ph(s, 1); tf = body.text_frame
    body.left, body.top, body.width, body.height = Inches(0.92), Inches(2.0), Inches(8.5), Inches(3.7)
    size = 24 if len(toc) <= 5 else 20
    for i, t in enumerate(toc):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        pPr = p._p.get_or_add_pPr(); pPr.set("marL", "0"); pPr.set("indent", "0")
        from lxml import etree
        from pptx.oxml.ns import qn
        etree.SubElement(pPr, qn("a:buNone"))
        r1 = p.add_run(); r1.text = "%02d" % (i + 1) + "   "; r1.font.size = Pt(size); r1.font.bold = True
        r1.font.color.theme_color = TC.ACCENT_1
        r2 = p.add_run(); r2.text = t; r2.font.size = Pt(size); r2.font.bold = False
        p.space_after = Pt(8)
    add_slide_number(s)

    # 3) 내용 슬라이드
    for sd in slides:
        t = sd["type"]; mode = sd.get("icon_mode", icon_mode)
        if t == "section":
            s = prs.slides.add_slide(lay[L_SEC_L])
            s.shapes.title.text_frame.text = sd["title"]
            ph(s, 1).text_frame.text = sd.get("subtitle", "")
            drop_unused(s, keep=(0, 1)); add_slide_number(s); continue
        s = prs.slides.add_slide(lay[L_CONTENT])
        set_title(s, sd["title"], 36)
        if t == "bullets":
            fill_bullets(ph(s, 1), sd["bullets"], bool(sd.get("icon")))
            if sd.get("icon"):
                ns.side_icon(s, sd["icon"], mode)
        else:
            drop_unused(s, keep=(0,))
            if t == "process": ns.process(s, sd["steps"], mode)
            elif t == "compare": ns.compare(s, sd["left"], sd["right"], mode)
            elif t == "cards": ns.cards(s, sd["cards"], mode)
            elif t == "timeline": ns.timeline(s, sd["events"], mode)
            elif t == "stats": ns.stats(s, sd["stats"], mode)
            else: raise ValueError("알 수 없는 type: %s" % t)
        if sd.get("notes"):
            s.notes_slide.notes_text_frame.text = sd["notes"]
        add_slide_number(s)

    # 4) Q&A (질문 유도)
    s = prs.slides.add_slide(lay[L_CLOSE])
    s.shapes.title.text_frame.text = spec.get("closing_title", cfg["closing_title"])
    ph(s, 1).text_frame.text = spec.get("closing_message", cfg["closing_message"])
    drop_unused(s, keep=(0, 1)); add_slide_number(s)

    prs.core_properties.title = spec["title"]
    prs.core_properties.author = cfg["name"]
    prs.save(out)
    return prs


def export_svgs(pptx_path, svg_dir):
    """pptx 안에 삽입된 SVG 를 꺼내 별도 파일로도 저장(편집/재사용용)"""
    import zipfile
    d = pathlib.Path(svg_dir); d.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(pptx_path) as z:
        for name in z.namelist():
            if name.startswith("ppt/media/") and name.endswith(".svg"):
                (d / pathlib.Path(name).name).write_bytes(z.read(name)); n += 1
    return n


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("deck_json"); ap.add_argument("out_pptx")
    ap.add_argument("--icon-mode", choices=["svg", "native"], default="svg")
    a = ap.parse_args()
    spec = json.load(open(a.deck_json, encoding="utf8"))
    build(spec, a.out_pptx, a.icon_mode)
    out = pathlib.Path(a.out_pptx)
    n = export_svgs(a.out_pptx, out.with_name(out.stem + "_svg"))
    print("saved:", a.out_pptx, "| SVG 파일 %d개 -> %s_svg/" % (n, out.stem))
    for w in ns.WARNINGS:
        print(w)
